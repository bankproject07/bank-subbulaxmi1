package com.cg.obs.dao;

import javax.security.auth.login.AccountException;

import com.cg.obs.bean.AccountMaster;
import com.cg.obs.bean.Admin;
import com.cg.obs.bean.Customer;
import com.cg.obs.exception.UserException;

public interface IAdminDao {

	public Admin getAdmin(String id) throws UserException;
	public int addUsers(Customer customer,AccountMaster account) throws UserException;
}
