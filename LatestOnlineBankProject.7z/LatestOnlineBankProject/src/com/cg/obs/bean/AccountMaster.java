package com.cg.obs.bean;

import java.sql.Date;

import sun.util.resources.LocaleData;

public class AccountMaster
{
	private int accountId;
	private String accountType;
	private float account_bal;
	private Date open_date;
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public float getAccount_bal() {
		return account_bal;
	}
	public void setAccount_bal(float account_bal) {
		this.account_bal = account_bal;
	}
	public Date getOpen_date() {
		return open_date;
	}
	public void setOpen_date(Date open_date) {
		this.open_date = open_date;
	}
	public AccountMaster(int accountId, String accountType, float account_bal, Date open_date) {
		super();
		this.accountId = accountId;
		this.accountType = accountType;
		this.account_bal = account_bal;
		this.open_date = open_date;
	}
	public AccountMaster() {
		super();
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + accountId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AccountMaster other = (AccountMaster) obj;
		if (accountId != other.accountId)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "AccountMaster [accountId=" + accountId + ", accountType=" + accountType + ", account_bal=" + account_bal
				+ ", open_date=" + open_date + "]";
	}
	
	
	
}
