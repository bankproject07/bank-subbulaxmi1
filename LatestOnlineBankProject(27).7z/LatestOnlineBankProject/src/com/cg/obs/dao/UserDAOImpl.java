package com.cg.obs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import com.cg.obs.bean.Customer;
import com.cg.obs.bean.FundTransfer;
import com.cg.obs.bean.RequestTable;
import com.cg.obs.bean.ServiceTracker;
import com.cg.obs.bean.Transactions;
import com.cg.obs.bean.Users;
import com.cg.obs.exception.UserException;
import com.cg.obs.util.DBUtil;

public class UserDAOImpl implements IUserDAO {

	PreparedStatement pst;
	Connection con;
	Statement st;
	@Override
	public Users getUser(int id) throws UserException {
		
		Users user=null;
		try {
			con=DBUtil.getConnection();
			String sql="SELECT * FROM USER_TABLE WHERE USER_ID=?";
			pst=con.prepareStatement(sql);
			pst.setInt(1, id);
			ResultSet rs=pst.executeQuery();
			rs.next();
			user=new Users();
		
			user.setUserId(rs.getInt(1));
			user.setAccountId(rs.getLong(2));
			user.setLoginPassword(rs.getString(3));
			user.setSecretQuestion(rs.getString(4));
			user.setSecretAns(rs.getString(5));
			user.setLockStatus(rs.getString(6));
			user.setTransPassword(rs.getString(7));
			
			
			System.out.println(user);
			
		} 
		catch (SQLException e) {
			
			throw new UserException("Problem occured while getting user details");
			//e.printStackTrace();
		}
		return user;
	}
	@Override
	public List<Transactions> getMiniTransactions(Long accountno) throws UserException {
		
		Transactions transaction=null;
		List<Transactions> transactionList=null;
		
		try {
			con=DBUtil.getConnection();
			String sql="SELECT * FROM Transaction WHERE Account_ID=? LIMIT 10";
			pst=con.prepareStatement(sql);
			pst.setLong(1, accountno);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
			transaction=new Transactions();
			transaction.setTransaction_ID(rs.getInt(1));
			transaction.setTran_Description(rs.getString(2));
			transaction.setDateOfTransaction(rs.getDate(3));
			transaction.setTransactionType(rs.getString(4).charAt(0));
			transaction.setTransactionAmount(rs.getLong(5));
			transaction.setAccountID(rs.getLong(6));
			transactionList.add(transaction);
			}
			
		} 
		catch (SQLException e) {
			
			throw new UserException("Problem occured while getting transaction details");
			//e.printStackTrace();
		}
		
		return transactionList;
	}
	@Override
	public List<Transactions> getDetailedTransactions(Long accountno) throws UserException {
		
		Transactions transaction=null;
		List<Transactions> transactionList=null;
		
		try {
			con=DBUtil.getConnection();
			String sql="SELECT * FROM Transaction WHERE Account_ID=?";
			pst=con.prepareStatement(sql);
			pst.setLong(1, accountno);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
			transaction=new Transactions();
			transaction.setTransaction_ID(rs.getInt(1));
			transaction.setTran_Description(rs.getString(2));
			transaction.setDateOfTransaction(rs.getDate(3));
			transaction.setTransactionType(rs.getString(4).charAt(0));
			transaction.setTransactionAmount(rs.getLong(5));
			transaction.setAccountID(rs.getLong(6));
			transactionList.add(transaction);
			}
			
		} 
		catch (SQLException e) {
			
			throw new UserException("Problem occured while getting transaction details");
			//e.printStackTrace();
		}
		
		return transactionList;
	}
	
	@Override
	public void updateCustomerDetails(Customer customer) throws UserException {
		
		try {
			con=DBUtil.getConnection();
			String sql="UPDATE Customer SET Mobile_No=? AND Address=? WHERE Customer_ID=?";
			pst=con.prepareStatement(sql);
			pst.setLong(1, customer.getMobileNo());
			pst.setString(2, customer.getAddress());
			
			pst.execute();			
		} 
		catch (SQLException e) {
			
			throw new UserException("Problem occured while update customer contact details");
			//e.printStackTrace();
		}
		
	}
	@Override
	public int requestService(ServiceTracker services) throws UserException {
		
		int requestId=-1;
		try {
			con=DBUtil.getConnection();
		
			Statement stm=con.createStatement();
			ResultSet rs=stm.executeQuery("select seq_service_num.nextVal from dual");
			if(rs.next()==false)
				System.out.println("Something went wrong");
			int id=rs.getInt(1);
			services.setService_ID(id);
			String insertQuery="INSERT INTO Service_Tracker VALUES(?,?,?,?,?)";
			pst=con.prepareStatement(insertQuery);
			pst.setLong(1, id);
			pst.setString(2, services.getService_Description());
			pst.setLong(3, services.getAccount_ID());
			pst.setDate(4 , services.getService_Raised_Date());
			pst.setString(5, services.getService_Status());
			pst.executeUpdate();
			requestId=id;
			
		} catch (SQLException e) {
			
			throw new UserException("Problem occured while requesting service");
			//e.printStackTrace();
		}
		return requestId;
	}
	@Override
	public int fundTransfer(FundTransfer transferInfo) throws UserException {
		
		int transferId=-1;
		try {
			con=DBUtil.getConnection();
		
			Statement stm=con.createStatement();
			ResultSet rs=stm.executeQuery("select seq_fundtransfer_id.nextVal from dual");
			if(rs.next()==false)
				System.out.println("Something went wrong");
			int id=rs.getInt(1);
			transferInfo.setFundTransfer_Id(id);
			String insertQuery="INSERT INTO Fund_Transfer VALUES(?,?,?,?,?)";
			pst=con.prepareStatement(insertQuery);
			pst.setLong(1, id);
			pst.setLong(2, transferInfo.getAccount_Id());
			pst.setLong(3, transferInfo.getPayee_Account());
			pst.setDate(4 ,transferInfo.getDateOfTransfer());
			pst.setLong(5, transferInfo.getTransferAmount());
			pst.executeUpdate();
			transferId=id;
			
		} catch (SQLException e) {
			
			throw new UserException("Problem occured while performing funds transfer");
			//e.printStackTrace();
		}
		return transferId;
	}
	@Override
	public void changePassword(Users user) throws UserException {
	
		int userid=user.getUserId();
		try {
			con=DBUtil.getConnection();
			String updateQuery="Update table User_Table set login_password=? where user_id=?";
			pst=con.prepareStatement(updateQuery);
			pst.setString(1, user.getLoginPassword());
			pst.setInt(2, user.getUserId());
			pst.executeUpdate();
		
		}catch (SQLException e) {
			
			throw new UserException("Problem occured while changing password");
			//e.printStackTrace();
		}	

}
	@Override
	public int registerUser(Users user, Customer customer) throws UserException
	{
	
		int accountId = -1;
		try
		{
			con = DBUtil.getConnection();
			String sequenceuser = "select user_seq.nextVal from dual";
			String accSequence ="select accid_seq.nextVal from dual";
			st= con.createStatement();
			ResultSet res=st.executeQuery(sequenceuser);
			ResultSet res1 =st.executeQuery(accSequence);
			while(res.next()== false || res1.next()==false)
			{
				throw new UserException("Something when wromg while generating data ");
			}
			//user
			int userid = res.getInt(1);
			int accId = res1.getInt(2);
			String loginpass = user.getLoginPassword();
			String transPass = user.getTransPassword();
			String secretQ = user.getSecretQuestion();
			String answer = user.getSecretAns();
			String lock = user.getLockStatus();
			//customer 
			String custname = customer.getCustomer_Name();
			String address = customer.getAddress();
			String mail = customer.getEmail();
			String pancard = customer.getPancard();
			
			//insert query.
			String insertuser="insert into user_table values(?,?,?,?,?,?,?)";
			String insertCust ="insert into customer values(?,?,?,?,?)";
			
			pst=con.prepareStatement(insertuser);
			pst.setInt(1, userid);
			pst.setInt(2, accId);
			pst.setString(3, loginpass);
			pst.setString(4, secretQ);
			pst.setString(5, sequenceuser);
			pst.setString(6, transPass);
			pst.setString(7, lock);
			pst.executeQuery();
			
			pst= con.prepareStatement(insertCust);
			pst.setInt(1, accId);
			pst.setString(2, custname);
			pst.setString(3, mail);
			pst.setString(4, address);
			pst.setString(5, pancard);
			pst.executeQuery();
			
			accountId=accId;
			
			
		}
		catch (SQLException e)
		{
			
			throw new UserException("Error occured while adding data : reason "+e.getMessage());
			
		}
		
		return accountId;
	}
	@Override
	public void updateLockStatus(int userid) throws UserException {
		
		
		try {
			con=DBUtil.getConnection();
			String updateQuery="Update table User_Table set lock_status=? where user_id=?";
			pst=con.prepareStatement(updateQuery);
			pst.setString(1, "L");
			pst.setInt(2, userid);
			pst.executeUpdate();
		
		}catch (SQLException e) {
			
			throw new UserException("Problem occured while changing password");
			//e.printStackTrace();
		}	
		
	}
	@Override
	public int addRequest(RequestTable resTab) throws UserException {
		int custid = -1;
		try 
		{
			con = DBUtil.getConnection();
			String cust_seq = "select custid_seq from dual";
			st= con.createStatement();
			ResultSet res=st.executeQuery(cust_seq);
			while(res.next())
			{
				throw new UserException("Something when wromg while generating id ");
			}
			int cust_id = res.getInt(1);
			String type=resTab.getType();
			float bal = resTab.getBalance();
			
			String insertReq = "insert into RequestTable values(?,?,?)";
			pst=con.prepareStatement(insertReq);
			pst.setInt(1, cust_id);
			pst.setString(2, type);
			pst.setFloat(3, bal);
			pst.executeQuery();
			
			custid = cust_id;
			
		}
		catch (SQLException e) 
		{
			throw new UserException("Unable to add Details in Request Table  " + e.getMessage());
		}
		return custid;
	}
}
